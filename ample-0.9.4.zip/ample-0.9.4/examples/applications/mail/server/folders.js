[
 {"id":	"My Folder"},
 {"id":	"Other Folder"},
 {"id":	"Second Folder"}
]